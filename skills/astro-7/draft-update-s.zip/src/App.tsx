import { useMemo, useState } from "react";
import skillMarkdownRaw from "./content/skill.md?raw";
import { TopBar } from "./components/TopBar";
import { Sidebar } from "./components/Sidebar";
import { MarkdownArticle } from "./components/MarkdownArticle";
import { parseFrontmatter } from "./lib/frontmatter";
import { extractTableOfContents } from "./lib/toc";
import { useActiveHeading } from "./hooks/useActiveHeading";
import { ArrowUp, ShieldCheck } from "lucide-react";

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);

  const { meta, body } = useMemo(() => parseFrontmatter(skillMarkdownRaw), []);
  const toc = useMemo(() => extractTableOfContents(skillMarkdownRaw), []);
  const activeId = useActiveHeading(useMemo(() => toc.map((item) => item.id), [toc]));

  return (
    <div className="min-h-screen bg-ink-950 text-ink-300">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-flame-500 focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-white"
      >
        Skip to content
      </a>

      <div id="top" />
      <TopBar rawMarkdown={skillMarkdownRaw} onOpenMenu={() => setMenuOpen(true)} />

      <div className="mx-auto flex max-w-[1440px]">
        <Sidebar items={toc} activeId={activeId} isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

        <div className="min-w-0 flex-1">
          {/* Hero */}
          <section className="border-b border-ink-800 px-4 py-14 sm:px-8 sm:py-20 lg:px-12">
            <div className="mx-auto max-w-3xl">
              <p className="font-mono text-xs font-medium uppercase tracking-[0.2em] text-flame-400">
                Skill reference &middot; {meta.name ?? "astro"}
              </p>
              <h1 className="mt-3 font-display text-4xl font-bold leading-tight tracking-tight text-ink-100 sm:text-5xl">
                The islands architecture,
                <br className="hidden sm:block" /> current as of Astro 6.
              </h1>
              <p className="mt-5 max-w-2xl text-lg leading-8 text-ink-300">
                A practical, verified reference for building content-focused sites with Astro — zero JS by
                default, opt-in hydration, the Content Layer API, and the Sessions, Fonts, and CSP APIs that
                stabilized in Astro 6. Includes a straight migration path if you're still on Astro 5.
              </p>
              <div className="mt-6 flex flex-wrap items-center gap-3 text-sm text-ink-400">
                <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-800/60 bg-emerald-950/40 px-3 py-1 text-emerald-300">
                  <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" />
                  Verified against docs.astro.build &amp; the official Astro changelog
                </span>
                <span className="text-ink-600">&bull;</span>
                <span>License: {meta.license ?? "See project LICENSE.txt"}</span>
              </div>

              {meta.description && (
                <details className="mt-8 rounded-lg border border-ink-800 bg-ink-900/50 open:pb-4">
                  <summary className="cursor-pointer select-none px-4 py-3 text-sm font-medium text-ink-200 hover:text-flame-400">
                    View full frontmatter <code className="text-xs text-ink-400">description</code> field
                  </summary>
                  <p className="border-t border-ink-800 px-4 pt-3 text-sm leading-6 text-ink-400">
                    {meta.description}
                  </p>
                </details>
              )}
            </div>
          </section>

          {/* Article */}
          <main id="main-content" className="px-4 py-12 sm:px-8 lg:px-12">
            <article className="mx-auto max-w-3xl">
              <MarkdownArticle content={body} />
            </article>
          </main>

          <footer className="border-t border-ink-800 px-4 py-10 sm:px-8 lg:px-12">
            <div className="mx-auto flex max-w-3xl flex-col gap-3 text-sm text-ink-400 sm:flex-row sm:items-center sm:justify-between">
              <p>
                Sources: official Astro docs, the Astro blog release notes, and the Astro GitHub changelog.
                Verify against <span className="font-mono text-ink-300">docs.astro.build</span> before pinning
                exact version numbers in production.
              </p>
              <a
                href="#top"
                className="inline-flex shrink-0 items-center gap-1.5 self-start rounded-md border border-ink-700 px-3 py-1.5 font-medium text-ink-300 hover:border-flame-500 hover:text-flame-400 sm:self-auto"
              >
                <ArrowUp className="h-3.5 w-3.5" aria-hidden="true" />
                Back to top
              </a>
            </div>
          </footer>
        </div>
      </div>
    </div>
  );
}
