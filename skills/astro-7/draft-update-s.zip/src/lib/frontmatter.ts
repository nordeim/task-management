export interface ParsedSkillDoc {
  meta: Record<string, string>;
  body: string;
}

/**
 * Splits a minimal YAML frontmatter block (flat "key: value" pairs only —
 * matches the shape used by this skill file) from the markdown body below it.
 */
export function parseFrontmatter(raw: string): ParsedSkillDoc {
  const lines = raw.split("\n");
  if (lines[0]?.trim() !== "---") {
    return { meta: {}, body: raw };
  }

  const meta: Record<string, string> = {};
  let endIndex = -1;

  for (let i = 1; i < lines.length; i++) {
    if (lines[i].trim() === "---") {
      endIndex = i;
      break;
    }
    const match = /^([a-zA-Z0-9_-]+):\s*(.*)$/.exec(lines[i]);
    if (match) {
      meta[match[1]] = match[2].trim();
    }
  }

  if (endIndex === -1) {
    return { meta: {}, body: raw };
  }

  const body = lines
    .slice(endIndex + 1)
    .join("\n")
    .replace(/^\s+/, "");

  return { meta, body };
}
