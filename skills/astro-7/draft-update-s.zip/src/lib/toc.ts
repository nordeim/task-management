export interface TocItem {
  id: string;
  text: string;
}

/**
 * Slugify a heading string the same way our custom heading renderer does,
 * so table-of-contents links always resolve to a real in-page anchor.
 */
export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[`*_]/g, "")
    .replace(/[^\w\s-]+/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

/** Strip inline markdown code markers so heading text matches the rendered DOM text. */
function stripInlineMarkdown(text: string): string {
  return text.replace(/`/g, "").trim();
}

export function headingId(rawHeadingText: string): string {
  return slugify(stripInlineMarkdown(rawHeadingText));
}

/**
 * Extract level-2 ("## ") headings from the raw markdown source to drive the
 * sidebar navigation, skipping frontmatter and fenced code blocks so a "##"
 * inside a code sample is never mistaken for a real section heading.
 */
export function extractTableOfContents(markdown: string): TocItem[] {
  const lines = markdown.split("\n");
  const items: TocItem[] = [];

  let dashSeparatorCount = 0;
  let inFrontmatter = false;
  let inCodeFence = false;

  for (const line of lines) {
    const trimmed = line.trim();

    if (trimmed === "---" && !inCodeFence) {
      dashSeparatorCount += 1;
      if (dashSeparatorCount === 1) {
        inFrontmatter = true;
        continue;
      }
      if (dashSeparatorCount === 2) {
        inFrontmatter = false;
        continue;
      }
    }

    if (inFrontmatter) continue;

    if (trimmed.startsWith("```")) {
      inCodeFence = !inCodeFence;
      continue;
    }
    if (inCodeFence) continue;

    const match = /^##\s+(.+)$/.exec(trimmed);
    if (match) {
      const rawText = match[1].trim();
      items.push({ id: headingId(rawText), text: stripInlineMarkdown(rawText) });
    }
  }

  return items;
}
