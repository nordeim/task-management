import { Check, Copy, Download, Menu, Rocket } from "lucide-react";
import { useClipboard } from "../hooks/useClipboard";

interface TopBarProps {
  rawMarkdown: string;
  onOpenMenu: () => void;
}

const BADGES = ["Astro 6.0+", "Node 22.12+", "Vite 7", "Content Layer API", "Updated 2026"];

function downloadSkillFile(content: string) {
  const blob = new Blob([content], { type: "text/markdown;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "SKILL.md";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function TopBar({ rawMarkdown, onOpenMenu }: TopBarProps) {
  const { copied, copy } = useClipboard();

  return (
    <header className="sticky top-0 z-30 border-b border-ink-800 bg-ink-950/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-[1440px] items-center gap-3 px-4 sm:px-6">
        <button
          type="button"
          onClick={onOpenMenu}
          className="-ml-1.5 rounded-md p-1.5 text-ink-300 hover:bg-ink-800 hover:text-ink-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-flame-500 lg:hidden"
          aria-label="Open table of contents"
        >
          <Menu className="h-5 w-5" aria-hidden="true" />
        </button>

        <a href="#top" className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-flame-500 to-flame-600 shadow-lg shadow-flame-500/20">
            <Rocket className="h-4.5 w-4.5 text-white" aria-hidden="true" />
          </span>
          <span className="font-display text-[15px] font-semibold tracking-tight text-ink-100 sm:text-base">
            Astro 6 Field Guide
          </span>
        </a>

        <div className="slim-scroll ml-2 hidden flex-1 items-center gap-2 overflow-x-auto md:flex">
          {BADGES.map((badge) => (
            <span
              key={badge}
              className="shrink-0 rounded-full border border-ink-700 bg-ink-900 px-2.5 py-1 font-mono text-[11px] font-medium text-ink-300"
            >
              {badge}
            </span>
          ))}
        </div>

        <div className="ml-auto flex shrink-0 items-center gap-2">
          <button
            type="button"
            onClick={() => copy(rawMarkdown)}
            className="inline-flex items-center gap-1.5 rounded-md border border-ink-700 bg-ink-900 px-2.5 py-1.5 text-xs font-medium text-ink-200 transition-colors hover:border-ink-600 hover:bg-ink-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-flame-500 sm:text-sm"
          >
            {copied ? (
              <>
                <Check className="h-4 w-4 text-emerald-400" aria-hidden="true" />
                <span className="hidden sm:inline">Copied</span>
              </>
            ) : (
              <>
                <Copy className="h-4 w-4" aria-hidden="true" />
                <span className="hidden sm:inline">Copy markdown</span>
              </>
            )}
          </button>
          <button
            type="button"
            onClick={() => downloadSkillFile(rawMarkdown)}
            className="inline-flex items-center gap-1.5 rounded-md bg-flame-500 px-2.5 py-1.5 text-xs font-semibold text-white shadow-sm shadow-flame-500/30 transition-colors hover:bg-flame-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-flame-400 sm:text-sm"
          >
            <Download className="h-4 w-4" aria-hidden="true" />
            <span className="hidden sm:inline">SKILL.md</span>
          </button>
        </div>
      </div>
    </header>
  );
}
