import { isValidElement, type ReactNode } from "react";
import { Check, Copy } from "lucide-react";
import { useClipboard } from "../hooks/useClipboard";

function getNodeText(node: ReactNode): string {
  if (node === null || node === undefined || typeof node === "boolean") return "";
  if (typeof node === "string" || typeof node === "number") return String(node);
  if (Array.isArray(node)) return node.map(getNodeText).join("");
  if (isValidElement<{ children?: ReactNode }>(node)) return getNodeText(node.props.children);
  return "";
}

function getLanguage(node: ReactNode): string | null {
  if (isValidElement<{ className?: string; children?: ReactNode }>(node)) {
    const match = /language-(\w+)/.exec(node.props.className ?? "");
    if (match) return match[1];
    return getLanguage(node.props.children);
  }
  if (Array.isArray(node)) {
    for (const child of node) {
      const found = getLanguage(child);
      if (found) return found;
    }
  }
  return null;
}

export function CodeBlock({ children }: { children: ReactNode }) {
  const raw = getNodeText(children).replace(/\n$/, "");
  const language = getLanguage(children);
  const { copied, copy } = useClipboard();

  return (
    <div className="group/code relative my-5 overflow-hidden rounded-xl border border-ink-700 bg-[#0d1117] shadow-[0_1px_0_0_rgba(255,255,255,0.03)_inset]">
      <div className="flex items-center justify-between border-b border-ink-700/80 bg-ink-900/60 px-4 py-2">
        <span className="font-mono text-[11px] font-medium uppercase tracking-wider text-ink-400">
          {language ?? "text"}
        </span>
        <button
          type="button"
          onClick={() => copy(raw)}
          className="inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-medium text-ink-300 transition-colors hover:bg-ink-700/60 hover:text-ink-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-flame-500"
          aria-label="Copy code to clipboard"
        >
          {copied ? (
            <>
              <Check className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />
              Copied
            </>
          ) : (
            <>
              <Copy className="h-3.5 w-3.5" aria-hidden="true" />
              Copy
            </>
          )}
        </button>
      </div>
      <pre className="slim-scroll overflow-x-auto p-4 text-[13px] leading-relaxed">{children}</pre>
    </div>
  );
}
