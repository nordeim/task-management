import { type ComponentPropsWithoutRef, type ReactNode } from "react";
import ReactMarkdown, { type Components } from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";
import { Hash } from "lucide-react";
import { CodeBlock } from "./CodeBlock";
import { headingId } from "../lib/toc";

function flattenText(node: ReactNode): string {
  if (typeof node === "string" || typeof node === "number") return String(node);
  if (Array.isArray(node)) return node.map(flattenText).join("");
  if (node && typeof node === "object" && "props" in node) {
    return flattenText((node as { props: { children?: ReactNode } }).props.children);
  }
  return "";
}

function makeHeading(level: 2 | 3 | 4) {
  const Tag = `h${level}` as "h2" | "h3" | "h4";
  const sizes: Record<2 | 3 | 4, string> = {
    2: "mt-16 scroll-mt-24 font-display text-2xl font-semibold tracking-tight text-ink-100 sm:text-3xl",
    3: "mt-10 scroll-mt-24 font-display text-xl font-semibold tracking-tight text-ink-100",
    4: "mt-8 scroll-mt-24 font-display text-base font-semibold tracking-tight text-ink-100",
  };

  function Heading({ children }: ComponentPropsWithoutRef<"h2">) {
    const id = headingId(flattenText(children));
    return (
      <Tag id={id} className={`group/heading relative ${sizes[level]}`}>
        <a
          href={`#${id}`}
          className="absolute -left-6 top-0.5 hidden text-flame-500 no-underline opacity-0 transition-opacity group-hover/heading:opacity-100 hover:text-flame-400 lg:inline-block"
          aria-label={`Link to this section`}
        >
          <Hash className="h-[0.85em] w-[0.85em]" aria-hidden="true" />
        </a>
        {children}
      </Tag>
    );
  }
  return Heading;
}

const components: Components = {
  h1: ({ children }) => (
    <h1 className="font-display text-3xl font-bold tracking-tight text-ink-100 sm:text-4xl">{children}</h1>
  ),
  h2: makeHeading(2),
  h3: makeHeading(3),
  h4: makeHeading(4),
  p: ({ children }) => <p className="my-4 leading-7 text-ink-300 [&_code]:text-flame-400">{children}</p>,
  a: ({ href, children }) => {
    const isExternal = href?.startsWith("http");
    return (
      <a
        href={href}
        target={isExternal ? "_blank" : undefined}
        rel={isExternal ? "noreferrer noopener" : undefined}
        className="font-medium text-flame-400 underline decoration-flame-500/40 underline-offset-4 transition-colors hover:text-flame-300 hover:decoration-flame-400"
      >
        {children}
      </a>
    );
  },
  ul: ({ children }) => <ul className="my-4 ml-5 list-disc space-y-2 text-ink-300 marker:text-flame-500">{children}</ul>,
  ol: ({ children }) => (
    <ol className="my-4 ml-5 list-decimal space-y-2 text-ink-300 marker:text-flame-500 marker:font-mono">{children}</ol>
  ),
  li: ({ children }) => <li className="pl-1 leading-7 [&_code]:text-flame-400">{children}</li>,
  strong: ({ children }) => <strong className="font-semibold text-ink-100">{children}</strong>,
  em: ({ children }) => <em className="text-ink-100">{children}</em>,
  hr: () => <hr className="my-12 border-ink-700" />,
  blockquote: ({ children }) => (
    <blockquote className="my-6 rounded-r-lg border-l-4 border-flame-500 bg-ink-800/60 py-3 pl-5 pr-4 text-ink-300 [&_p]:my-1.5 [&_strong]:text-ink-100">
      {children}
    </blockquote>
  ),
  table: ({ children }) => (
    <div className="slim-scroll my-6 overflow-x-auto rounded-lg border border-ink-700">
      <table className="w-full min-w-[560px] border-collapse text-left text-sm">{children}</table>
    </div>
  ),
  thead: ({ children }) => <thead className="bg-ink-800/80 text-ink-100">{children}</thead>,
  tbody: ({ children }) => <tbody className="divide-y divide-ink-700">{children}</tbody>,
  tr: ({ children }) => <tr className="even:bg-ink-900/40">{children}</tr>,
  th: ({ children }) => <th className="px-4 py-2.5 font-semibold">{children}</th>,
  td: ({ children }) => (
    <td className="px-4 py-2.5 align-top text-ink-300 [&_code]:text-flame-400">{children}</td>
  ),
  pre: ({ children }) => <CodeBlock>{children}</CodeBlock>,
  code: ({ className, children, ...props }) => {
    if (!className) {
      return (
        <code
          className="rounded-md border border-ink-700 bg-ink-800/80 px-1.5 py-0.5 font-mono text-[0.85em] text-flame-400"
          {...props}
        >
          {children}
        </code>
      );
    }
    return (
      <code className={`${className} font-mono`} {...props}>
        {children}
      </code>
    );
  },
};

export function MarkdownArticle({ content }: { content: string }) {
  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm]}
      rehypePlugins={[[rehypeHighlight, { ignoreMissing: true }]]}
      components={components}
    >
      {content}
    </ReactMarkdown>
  );
}
