import { X } from "lucide-react";
import { cn } from "../utils/cn";
import type { TocItem } from "../lib/toc";

interface SidebarProps {
  items: TocItem[];
  activeId: string | null;
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ items, activeId, isOpen, onClose }: SidebarProps) {
  const nav = (
    <nav aria-label="Table of contents" className="slim-scroll h-full overflow-y-auto px-4 py-6">
      <a
        href="#top"
        onClick={onClose}
        className="mb-4 flex items-center gap-2 px-2 text-xs font-semibold uppercase tracking-widest text-ink-400 hover:text-flame-400"
      >
        Contents
      </a>
      <ul className="space-y-0.5">
        {items.map((item) => {
          const active = item.id === activeId;
          return (
            <li key={item.id}>
              <a
                href={`#${item.id}`}
                onClick={onClose}
                aria-current={active ? "location" : undefined}
                className={cn(
                  "block rounded-md border-l-2 px-3 py-1.5 text-sm leading-snug transition-colors",
                  active
                    ? "border-flame-500 bg-flame-500/10 font-medium text-flame-300"
                    : "border-transparent text-ink-400 hover:border-ink-500 hover:bg-ink-800/60 hover:text-ink-100"
                )}
              >
                {item.text}
              </a>
            </li>
          );
        })}
      </ul>
    </nav>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="slim-scroll sticky top-16 hidden h-[calc(100vh-4rem)] w-72 shrink-0 border-r border-ink-800 lg:block">
        {nav}
      </aside>

      {/* Mobile drawer */}
      <div
        className={cn(
          "fixed inset-0 z-40 bg-black/60 backdrop-blur-sm transition-opacity lg:hidden",
          isOpen ? "opacity-100" : "pointer-events-none opacity-0"
        )}
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-80 max-w-[85vw] transform border-r border-ink-800 bg-ink-950 transition-transform duration-200 ease-out lg:hidden",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
        role="dialog"
        aria-modal="true"
        aria-label="Table of contents"
      >
        <div className="flex items-center justify-between border-b border-ink-800 px-4 py-3">
          <span className="text-xs font-semibold uppercase tracking-widest text-ink-400">Contents</span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1.5 text-ink-300 hover:bg-ink-800 hover:text-ink-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-flame-500"
            aria-label="Close table of contents"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>
        <div className="h-[calc(100%-3rem)]">{nav}</div>
      </div>
    </>
  );
}
