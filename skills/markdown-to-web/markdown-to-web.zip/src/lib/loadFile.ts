const MAX_FILE_BYTES = 5 * 1024 * 1024; // keep in sync with lib/document.ts's parse-time guard
const ACCEPTED_EXTENSIONS = [".md", ".markdown", ".mdx", ".txt"];

export class FileValidationError extends Error {}

function hasAcceptedExtension(name: string): boolean {
  const lower = name.toLowerCase();
  return ACCEPTED_EXTENSIONS.some((ext) => lower.endsWith(ext));
}

/**
 * Reads a user-provided file as text after validating type and size. Rejects
 * before ever handing bytes to a parser, since an oversized or binary file is
 * cheaper to refuse here than to fail deep inside the Markdown pipeline.
 */
export function readMarkdownFile(file: File): Promise<string> {
  if (!hasAcceptedExtension(file.name) && file.type && !file.type.startsWith("text/")) {
    return Promise.reject(new FileValidationError(`"${file.name}" doesn't look like a text/Markdown file.`));
  }
  if (file.size > MAX_FILE_BYTES) {
    return Promise.reject(
      new FileValidationError(`"${file.name}" is ${(file.size / (1024 * 1024)).toFixed(1)} MB — the limit is 5 MB.`),
    );
  }

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : "");
    reader.onerror = () => reject(new FileValidationError(`Couldn't read "${file.name}".`));
    reader.readAsText(file);
  });
}
