import matter from "gray-matter";

export interface DocumentMeta {
  title?: string;
  description?: string;
  author?: string;
  date?: string;
  tags: string[];
}

export interface ParsedDocument {
  meta: DocumentMeta;
  /** Markdown body with frontmatter removed, ready for the renderer. */
  content: string;
  wordCount: number;
  readingTimeMinutes: number;
}

const WORDS_PER_MINUTE = 200;
const MAX_SOURCE_BYTES = 5 * 1024 * 1024; // 5 MB — generous for a text document, bounds worst-case parse cost

export class DocumentTooLargeError extends Error {
  constructor(sizeBytes: number) {
    super(`Document is ${(sizeBytes / (1024 * 1024)).toFixed(1)} MB, which exceeds the 5 MB limit.`);
    this.name = "DocumentTooLargeError";
  }
}

/**
 * Parses raw Markdown text (optionally with YAML frontmatter) into structured
 * metadata plus a body ready for rendering. Never throws on malformed
 * frontmatter — falls back to treating the whole input as body content, since
 * a broken YAML header should degrade gracefully rather than blank the page.
 */
export function parseDocument(raw: string): ParsedDocument {
  const sizeBytes = new Blob([raw]).size;
  if (sizeBytes > MAX_SOURCE_BYTES) {
    throw new DocumentTooLargeError(sizeBytes);
  }

  let data: Record<string, unknown> = {};
  let content = raw;
  try {
    const parsed = matter(raw);
    data = parsed.data ?? {};
    content = parsed.content;
  } catch {
    // Malformed frontmatter delimiters/YAML: render the raw text as-is rather than failing the whole document.
    content = raw;
  }

  content = content.trim();
  const wordCount = countWords(content);

  return {
    meta: normalizeMeta(data),
    content,
    wordCount,
    readingTimeMinutes: Math.max(1, Math.round(wordCount / WORDS_PER_MINUTE)),
  };
}

function normalizeMeta(data: Record<string, unknown>): DocumentMeta {
  return {
    title: typeof data.title === "string" ? data.title : undefined,
    description: typeof data.description === "string" ? data.description : undefined,
    author: typeof data.author === "string" ? data.author : undefined,
    date: toIsoDate(data.date),
    tags: Array.isArray(data.tags) ? data.tags.filter((tag): tag is string => typeof tag === "string") : [],
  };
}

function toIsoDate(value: unknown): string | undefined {
  if (typeof value === "string" && value.trim()) return value.trim();
  if (value instanceof Date && !Number.isNaN(value.getTime())) return value.toISOString().slice(0, 10);
  return undefined;
}

function countWords(markdown: string): number {
  const stripped = markdown
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/`[^`]*`/g, " ")
    .replace(/!\[[^\]]*\]\([^)]*\)/g, " ")
    .replace(/\[([^\]]*)\]\([^)]*\)/g, "$1")
    .replace(/[#>*_~-]/g, " ");
  const matches = stripped.match(/\S+/g);
  return matches ? matches.length : 0;
}
