import type { Blockquote, Root, Text } from "mdast";
import { visit } from "unist-util-visit";

export const CALLOUT_TYPES = ["note", "tip", "important", "warning", "caution"] as const;
export type CalloutType = (typeof CALLOUT_TYPES)[number];

const MARKER_PATTERN = /^\[!(NOTE|TIP|IMPORTANT|WARNING|CAUTION)\]\s*/i;

/**
 * Remark plugin that upgrades GitHub-style alert blockquotes
 * (`> [!NOTE]`, `> [!TIP]`, `> [!IMPORTANT]`, `> [!WARNING]`, `> [!CAUTION]`)
 * into `<div data-callout="...">` containers so `MarkdownRenderer` can style
 * them distinctly from ordinary quotes. Unrecognized blockquotes are left
 * untouched and render as normal `<blockquote>` elements.
 */
export function remarkCallouts() {
  return (tree: Root) => {
    visit(tree, "blockquote", (node: Blockquote) => {
      const firstParagraph = node.children[0];
      if (!firstParagraph || firstParagraph.type !== "paragraph") return;

      const firstChild = firstParagraph.children[0];
      if (!firstChild || firstChild.type !== "text") return;

      const match = firstChild.value.match(MARKER_PATTERN);
      if (!match) return;

      const calloutType = match[1].toLowerCase() as CalloutType;
      const remainder = firstChild.value.slice(match[0].length);

      if (remainder.trim()) {
        (firstChild as Text).value = remainder;
      } else {
        firstParagraph.children.shift();
        if (firstParagraph.children.length === 0) {
          node.children.shift();
        }
      }

      node.data = {
        ...node.data,
        hName: "div",
        hProperties: {
          "data-callout": calloutType,
          role: "note",
          "aria-label": calloutType,
        },
      };
    });
  };
}


