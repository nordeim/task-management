import remarkGfm from "remark-gfm";
import remarkParse from "remark-parse";
import { unified } from "unified";
import { toString as mdastToString } from "mdast-util-to-string";
import GithubSlugger from "github-slugger";
import type { Heading, Root, RootContent } from "mdast";

export interface SearchSection {
  id: string;
  level: 1 | 2 | 3 | 4;
  heading: string;
  /** Plain-text excerpt of the section body, used both for matching and result preview. */
  excerpt: string;
}

/**
 * Splits a document into heading-anchored sections with plain-text bodies,
 * so in-document search can match on rendered content (not raw Markdown
 * syntax like `**` or `[text](url)`) and still resolve to a real anchor.
 */
export function buildSearchIndex(markdown: string): SearchSection[] {
  const tree = unified().use(remarkParse).use(remarkGfm).parse(markdown) as Root;
  const slugger = new GithubSlugger();
  const sections: SearchSection[] = [];

  let current: SearchSection | null = null;
  const bodyParts: string[] = [];

  const flush = () => {
    if (current) sections.push({ ...current, excerpt: bodyParts.join(" ").trim().slice(0, 220) });
    bodyParts.length = 0;
  };

  for (const node of tree.children as RootContent[]) {
    if (node.type === "heading" && node.depth <= 4) {
      flush();
      const heading = node as Heading;
      const text = mdastToString(heading);
      current = { id: slugger.slug(text), level: heading.depth as 1 | 2 | 3 | 4, heading: text, excerpt: "" };
    } else if (current) {
      const text = mdastToString(node).trim();
      if (text) bodyParts.push(text);
    }
  }
  flush();

  return sections;
}

export interface SearchMatch extends SearchSection {
  /** True when the query matched the heading text rather than only the body. */
  matchedHeading: boolean;
}

export function searchSections(sections: SearchSection[], query: string): SearchMatch[] {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return [];

  return sections
    .map((section) => {
      const matchedHeading = section.heading.toLowerCase().includes(normalized);
      const matchedBody = section.excerpt.toLowerCase().includes(normalized);
      if (!matchedHeading && !matchedBody) return null;
      return { ...section, matchedHeading };
    })
    .filter((result): result is SearchMatch => result !== null)
    .sort((a, b) => Number(b.matchedHeading) - Number(a.matchedHeading));
}
