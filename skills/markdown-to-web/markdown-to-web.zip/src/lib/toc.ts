import GithubSlugger from "github-slugger";

export type HeadingLevel = 1 | 2 | 3 | 4;

export interface TocItem {
  id: string;
  level: HeadingLevel;
  text: string;
  children: TocItem[];
}

interface FlatHeading {
  level: HeadingLevel;
  text: string;
  id: string;
}

const HEADING_PATTERN = /^(#{1,4})\s+(.+?)\s*#*$/;
const FENCE_PATTERN = /^\s*(```|~~~)/;

/**
 * Extracts an H1-H4 outline from raw markdown and nests it into a nested tree.
 *
 * Uses `github-slugger` directly, the same slug algorithm `rehype-slug`
 * relies on internally, so anchors generated here always match the `id`
 * attributes react-markdown renders onto headings. Never re-derive slugs
 * from anywhere else, or TOC links will silently point at the wrong anchor.
 */
export function buildToc(markdown: string): TocItem[] {
  const slugger = new GithubSlugger();
  const flat: FlatHeading[] = [];
  let inFence = false;
  let fenceMarker = "";

  for (const line of markdown.split("\n")) {
    const fenceMatch = line.match(FENCE_PATTERN);
    if (fenceMatch) {
      if (!inFence) {
        inFence = true;
        fenceMarker = fenceMatch[1];
      } else if (line.trim().startsWith(fenceMarker)) {
        inFence = false;
      }
      continue;
    }
    if (inFence) continue;

    const match = line.match(HEADING_PATTERN);
    if (!match) continue;

    const level = match[1].length as HeadingLevel;
    const text = match[2]
      .replace(/`/g, "")
      .replace(/\*\*?/g, "")
      .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
      .trim();
    if (!text) continue;

    flat.push({ level, text, id: slugger.slug(text) });
  }

  return nest(flat);
}

function nest(flat: FlatHeading[]): TocItem[] {
  const root: TocItem[] = [];
  const stack: TocItem[] = [];

  for (const heading of flat) {
    const node: TocItem = { ...heading, children: [] };
    while (stack.length && stack[stack.length - 1].level >= node.level) {
      stack.pop();
    }
    (stack.length ? stack[stack.length - 1].children : root).push(node);
    stack.push(node);
  }

  return root;
}

/** Flattens a TOC tree back into a single ordered list, used for search + active-heading lookups. */
export function flattenToc(items: TocItem[]): TocItem[] {
  return items.flatMap((item) => [item, ...flattenToc(item.children)]);
}
