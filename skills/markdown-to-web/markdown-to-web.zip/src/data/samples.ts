import featureTour from "@/content/samples/feature-tour.md?raw";
import onboardingHandbook from "@/content/samples/onboarding-handbook.md?raw";
import webhooksApiReference from "@/content/samples/webhooks-api-reference.md?raw";

export interface SampleDocument {
  id: string;
  label: string;
  raw: string;
}

/** Bundled documents demonstrating the reader against different content shapes — not the report itself. */
export const SAMPLE_DOCUMENTS: SampleDocument[] = [
  { id: "feature-tour", label: "Feature tour", raw: featureTour },
  { id: "onboarding-handbook", label: "Onboarding handbook", raw: onboardingHandbook },
  { id: "webhooks-api-reference", label: "API reference", raw: webhooksApiReference },
];

export const DEFAULT_SAMPLE_ID = SAMPLE_DOCUMENTS[0].id;
