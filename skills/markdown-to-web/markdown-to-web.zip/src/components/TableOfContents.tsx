import type { TocItem } from "@/lib/toc";
import { cn } from "@/utils/cn";

interface TableOfContentsProps {
  items: TocItem[];
  activeId: string | null;
  onNavigate?: () => void;
}

export function TableOfContents({ items, activeId, onNavigate }: TableOfContentsProps) {
  if (items.length === 0) {
    return <p className="px-1 text-sm text-ink-600 dark:text-paper-300/60">No headings found in this document.</p>;
  }

  return (
    <nav aria-label="Table of contents">
      <TocList items={items} activeId={activeId} onNavigate={onNavigate} depth={0} />
    </nav>
  );
}

function TocList({ items, activeId, onNavigate, depth }: TableOfContentsProps & { depth: number }) {
  return (
    <ul className={cn(depth > 0 && "mt-1 ml-3 space-y-1 border-l border-paper-200 pl-3 dark:border-ink-800")}>
      {items.map((item) => {
        const isActive = item.id === activeId;
        return (
          <li key={item.id}>
            <a
              href={`#${item.id}`}
              onClick={onNavigate}
              aria-current={isActive ? "location" : undefined}
              className={cn(
                "block rounded-md px-2 py-1.5 text-sm leading-snug transition",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-signal-500",
                isActive
                  ? "bg-signal-600/10 font-medium text-signal-700 dark:bg-signal-500/15 dark:text-signal-400"
                  : "text-ink-600 hover:bg-paper-100 hover:text-ink-900 dark:text-paper-300/80 dark:hover:bg-ink-800 dark:hover:text-paper-50",
              )}
            >
              {item.text}
            </a>
            {item.children.length > 0 && (
              <TocList items={item.children} activeId={activeId} onNavigate={onNavigate} depth={depth + 1} />
            )}
          </li>
        );
      })}
    </ul>
  );
}
