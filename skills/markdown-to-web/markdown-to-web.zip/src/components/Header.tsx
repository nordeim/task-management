import { ClipboardPaste, Feather, Menu, Monitor, Moon, Search, Sun, Upload } from "lucide-react";
import type { ChangeEvent, ReactNode, RefObject } from "react";
import type { ThemePreference } from "@/hooks/useTheme";
import type { SampleDocument } from "@/data/samples";
import { cn } from "@/utils/cn";
import { ReadingProgressBar } from "./ReadingProgressBar";

const THEME_ICON: Record<ThemePreference, typeof Sun> = { light: Sun, dark: Moon, system: Monitor };

interface HeaderProps {
  documentTitle: string;
  samples: SampleDocument[];
  activeSampleId: string | null;
  onSelectSample: (id: string) => void;
  fileInputRef: RefObject<HTMLInputElement | null>;
  onFileChosen: (event: ChangeEvent<HTMLInputElement>) => void;
  onOpenPaste: () => void;
  onOpenSearch: () => void;
  onToggleDrawer: () => void;
  themePreference: ThemePreference;
  onCycleTheme: () => void;
}

export function Header({
  documentTitle,
  samples,
  activeSampleId,
  onSelectSample,
  fileInputRef,
  onFileChosen,
  onOpenPaste,
  onOpenSearch,
  onToggleDrawer,
  themePreference,
  onCycleTheme,
}: HeaderProps) {
  const ThemeIcon = THEME_ICON[themePreference];

  return (
    <header className="sticky top-0 z-40 border-b border-paper-200 bg-paper-0/90 backdrop-blur dark:border-ink-800 dark:bg-ink-950/90">
      <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:px-6">
        <button
          type="button"
          onClick={onToggleDrawer}
          className="rounded-md p-2 text-ink-700 hover:bg-paper-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-signal-500 lg:hidden dark:text-paper-200 dark:hover:bg-ink-800"
          aria-label="Open table of contents"
        >
          <Menu className="h-5 w-5" aria-hidden />
        </button>

        <div className="flex min-w-0 items-center gap-2">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-signal-600 to-brand-600 text-white">
            <Feather className="h-4 w-4" aria-hidden />
          </span>
          <div className="min-w-0">
            <p className="font-display text-sm leading-none font-semibold text-ink-900 dark:text-paper-50">Folium</p>
            <p className="truncate text-xs leading-none text-ink-500 dark:text-paper-300/60" title={documentTitle}>
              {documentTitle}
            </p>
          </div>
        </div>

        <div className="ml-auto flex items-center gap-1 sm:gap-1.5">
          <label className="relative hidden sm:block">
            <span className="sr-only">Load a sample document</span>
            <select
              value={activeSampleId ?? ""}
              onChange={(event) => onSelectSample(event.target.value)}
              className="rounded-md border border-paper-200 bg-paper-0 py-1.5 pr-7 pl-2.5 text-xs font-medium text-ink-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-signal-500 dark:border-ink-700 dark:bg-ink-900 dark:text-paper-200"
            >
              {activeSampleId === null && (
                <option value="" disabled>
                  Custom document
                </option>
              )}
              {samples.map((sample) => (
                <option key={sample.id} value={sample.id}>
                  {sample.label}
                </option>
              ))}
            </select>
          </label>

          <IconButton label="Search document (/)" onClick={onOpenSearch}>
            <Search className="h-4 w-4" aria-hidden />
          </IconButton>

          <IconButton label="Paste Markdown" onClick={onOpenPaste}>
            <ClipboardPaste className="h-4 w-4" aria-hidden />
          </IconButton>

          <IconButton label="Open a Markdown file" onClick={() => fileInputRef.current?.click()}>
            <Upload className="h-4 w-4" aria-hidden />
          </IconButton>
          <input
            ref={fileInputRef}
            type="file"
            accept=".md,.markdown,.mdx,.txt,text/markdown,text/plain"
            className="hidden"
            onChange={onFileChosen}
          />

          <IconButton label={`Theme: ${themePreference}. Click to change.`} onClick={onCycleTheme}>
            <ThemeIcon className="h-4 w-4" aria-hidden />
          </IconButton>
        </div>
      </div>
      <ReadingProgressBar />
    </header>
  );
}

function IconButton({ label, onClick, children }: { label: string; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      title={label}
      className={cn(
        "flex h-9 w-9 items-center justify-center rounded-md text-ink-700 transition hover:bg-paper-100",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-signal-500",
        "dark:text-paper-200 dark:hover:bg-ink-800",
      )}
    >
      {children}
    </button>
  );
}
