import { Check, Copy } from "lucide-react";
import { useState, type ComponentPropsWithoutRef, type ReactNode } from "react";
import { cn } from "@/utils/cn";

function extractText(node: ReactNode): string {
  if (typeof node === "string") return node;
  if (typeof node === "number") return String(node);
  if (Array.isArray(node)) return node.map(extractText).join("");
  if (node && typeof node === "object" && "props" in node) {
    return extractText((node as { props: { children?: ReactNode } }).props.children);
  }
  return "";
}

function languageFromClassName(className: string | undefined): string | null {
  const match = className?.match(/language-(\w+)/);
  return match ? match[1] : null;
}

/**
 * Renders a fenced code block with a language label and a copy-to-clipboard
 * button. Falls back to `document.execCommand` when the async Clipboard API
 * is unavailable (e.g. insecure/non-HTTPS contexts), and never throws if
 * both are blocked — the button just silently reports no-op instead of
 * crashing the render.
 */
export function CodeBlock({ children, ...props }: ComponentPropsWithoutRef<"pre">) {
  const [copied, setCopied] = useState(false);
  const codeElement = Array.isArray(children) ? children[0] : children;
  const className =
    codeElement && typeof codeElement === "object" && "props" in codeElement
      ? (codeElement.props as { className?: string }).className
      : undefined;
  const language = languageFromClassName(className);
  const text = extractText(children).replace(/\n$/, "");

  const handleCopy = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        const textarea = document.createElement("textarea");
        textarea.value = text;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
      }
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard permission denied or unsupported — leave the button interactive, no crash.
    }
  };

  return (
    <div className="group relative my-5 overflow-hidden rounded-xl border border-ink-800 bg-ink-900 dark:border-ink-700">
      <div className="flex items-center justify-between border-b border-ink-800 px-4 py-2 dark:border-ink-700">
        <span className="font-mono text-xs tracking-wide text-paper-300/70 uppercase">{language ?? "text"}</span>
        <button
          type="button"
          onClick={handleCopy}
          className={cn(
            "inline-flex items-center gap-1.5 rounded-md px-2 py-1 font-mono text-xs text-paper-300/80",
            "transition hover:bg-ink-800 hover:text-paper-100",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-signal-500 focus-visible:ring-offset-2 focus-visible:ring-offset-ink-900",
          )}
          aria-label={copied ? "Code copied to clipboard" : "Copy code to clipboard"}
        >
          {copied ? <Check className="h-3.5 w-3.5" aria-hidden /> : <Copy className="h-3.5 w-3.5" aria-hidden />}
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <pre {...props} className="overflow-x-auto p-4 text-[0.85rem] leading-relaxed">
        {children}
      </pre>
    </div>
  );
}
