import type { DocumentMeta } from "@/lib/document";

interface DocumentInfoProps {
  meta: DocumentMeta;
  wordCount: number;
  readingTimeMinutes: number;
}

export function DocumentInfo({ meta, wordCount, readingTimeMinutes }: DocumentInfoProps) {
  const hasByline = meta.author || meta.date;

  return (
    <div className="mb-8 border-b border-paper-200 pb-6 dark:border-ink-800">
      {meta.title && (
        <h1 className="font-display text-3xl font-semibold text-ink-900 sm:text-4xl dark:text-paper-50">{meta.title}</h1>
      )}
      {meta.description && <p className="mt-2 text-base text-ink-600 dark:text-paper-300/80">{meta.description}</p>}

      <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 font-mono text-xs tracking-wide text-ink-600 uppercase dark:text-paper-300/60">
        {hasByline && (
          <span>
            {meta.author}
            {meta.author && meta.date ? " · " : ""}
            {meta.date}
          </span>
        )}
        <span>
          {wordCount.toLocaleString()} words · {readingTimeMinutes} min read
        </span>
      </div>

      {meta.tags.length > 0 && (
        <ul className="mt-3 flex flex-wrap gap-1.5">
          {meta.tags.map((tag) => (
            <li
              key={tag}
              className="rounded-full bg-paper-100 px-2.5 py-0.5 font-mono text-[0.7rem] tracking-wide text-ink-600 dark:bg-ink-800 dark:text-paper-300/80"
            >
              {tag}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
