import { useScrollProgress } from "@/hooks/useScrollProgress";

export function ReadingProgressBar() {
  const progress = useScrollProgress();

  return (
    <div className="absolute inset-x-0 bottom-0 h-0.5 bg-transparent" aria-hidden="true">
      <div
        className="h-full bg-signal-600 transition-[width] duration-150 ease-out dark:bg-signal-500"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
}
