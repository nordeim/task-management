import { AlertTriangle, Check, Info, Link as LinkIcon, Lightbulb, OctagonAlert, ShieldAlert } from "lucide-react";
import { useState, type ComponentPropsWithoutRef, type ReactNode } from "react";
import ReactMarkdown, { type Components } from "react-markdown";
import rehypeHighlight from "rehype-highlight";
import rehypeSlug from "rehype-slug";
import remarkGfm from "remark-gfm";
import { remarkCallouts } from "@/lib/callouts";
import { cn } from "@/utils/cn";
import { CodeBlock } from "./CodeBlock";

const CALLOUT_META = {
  note: { icon: Info, label: "Note", classes: "border-note/30 bg-note/[0.06] text-note dark:bg-note/10" },
  tip: { icon: Lightbulb, label: "Tip", classes: "border-tip/30 bg-tip/[0.06] text-tip dark:bg-tip/10" },
  important: {
    icon: ShieldAlert,
    label: "Important",
    classes: "border-important/30 bg-important/[0.06] text-important dark:bg-important/10",
  },
  warning: {
    icon: AlertTriangle,
    label: "Warning",
    classes: "border-warning/30 bg-warning/[0.06] text-warning dark:bg-warning/10",
  },
  caution: {
    icon: OctagonAlert,
    label: "Caution",
    classes: "border-caution/30 bg-caution/[0.06] text-caution dark:bg-caution/10",
  },
} as const;

type CalloutKey = keyof typeof CALLOUT_META;

function isCalloutKey(value: string | undefined): value is CalloutKey {
  return !!value && value in CALLOUT_META;
}

function HeadingAnchor({ id }: { id?: string }) {
  const [copied, setCopied] = useState(false);
  if (!id) return null;

  const handleClick = async () => {
    const url = `${window.location.origin}${window.location.pathname}#${id}`;
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      // Clipboard unavailable — the hash-only navigation below still succeeds.
    }
    window.history.replaceState(null, "", `#${id}`);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1500);
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      className={cn(
        "ml-2 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-md align-middle text-ink-400",
        "opacity-0 transition group-hover/heading:opacity-100 focus-visible:opacity-100",
        "hover:bg-paper-200 hover:text-signal-600 dark:hover:bg-ink-800 dark:hover:text-signal-500",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-signal-500",
      )}
      aria-label="Copy link to this section"
    >
      {copied ? <Check className="h-3.5 w-3.5" aria-hidden /> : <LinkIcon className="h-3.5 w-3.5" aria-hidden />}
    </button>
  );
}

function heading(level: 1 | 2 | 3 | 4 | 5 | 6) {
  const sizes: Record<number, string> = {
    1: "text-3xl sm:text-4xl mt-0 mb-5",
    2: "text-2xl sm:text-[1.7rem] mt-12 mb-4 pt-2 border-t border-paper-200 dark:border-ink-800 first:border-t-0 first:pt-0 first:mt-0",
    3: "text-xl sm:text-[1.3rem] mt-8 mb-3",
    4: "text-base sm:text-lg mt-6 mb-2",
    5: "text-base mt-5 mb-2",
    6: "text-sm mt-4 mb-2 uppercase tracking-wide",
  };

  function HeadingComponent({ id, children, ...rest }: ComponentPropsWithoutRef<"h1">) {
    const Tag = `h${level}` as const;
    return (
      <Tag
        id={id}
        {...rest}
        className={cn("group/heading scroll-mt-24 font-display font-semibold text-ink-900 dark:text-paper-100", sizes[level])}
      >
        {children}
        <HeadingAnchor id={id} />
      </Tag>
    );
  }
  HeadingComponent.displayName = `Heading${level}`;
  return HeadingComponent;
}

function ExternalLinkBadge() {
  return (
    <svg viewBox="0 0 24 24" className="ml-0.5 inline-block h-3 w-3 -translate-y-px" aria-hidden fill="none" stroke="currentColor" strokeWidth={2}>
      <path d="M7 17 17 7M9 7h8v8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

const components: Components = {
  h1: heading(1),
  h2: heading(2),
  h3: heading(3),
  h4: heading(4),
  h5: heading(5),
  h6: heading(6),
  p: ({ children }) => <p className="my-4 leading-7 text-ink-700 dark:text-paper-200/90">{children}</p>,
  a: ({ href, children }) => {
    const isExternal = /^https?:\/\//.test(href ?? "");
    return (
      <a
        href={href}
        target={isExternal ? "_blank" : undefined}
        rel={isExternal ? "noopener noreferrer" : undefined}
        className="font-medium text-signal-600 underline decoration-signal-600/30 underline-offset-2 hover:decoration-signal-600 dark:text-signal-500 dark:decoration-signal-500/40"
      >
        {children}
        {isExternal && <ExternalLinkBadge />}
      </a>
    );
  },
  strong: ({ children }) => <strong className="font-semibold text-ink-900 dark:text-paper-50">{children}</strong>,
  em: ({ children }) => <em className="italic">{children}</em>,
  ul: ({ children }) => <ul className="my-4 ml-5 list-disc space-y-1.5 marker:text-signal-600 dark:marker:text-signal-500">{children}</ul>,
  ol: ({ children }) => <ol className="my-4 ml-5 list-decimal space-y-1.5 marker:text-signal-600 dark:marker:text-signal-500">{children}</ol>,
  li: ({ children, className }) => (
    <li className={cn("leading-7 text-ink-700 dark:text-paper-200/90", className?.includes("task-list-item") && "ml-[-1.25rem] list-none")}>
      {children}
    </li>
  ),
  input: ({ checked, disabled }) => (
    <input
      type="checkbox"
      checked={checked}
      disabled={disabled}
      readOnly
      className="mr-2 h-4 w-4 rounded border-paper-300 align-middle accent-signal-600"
    />
  ),
  hr: () => <hr className="my-10 border-paper-200 dark:border-ink-800" />,
  // Ordinary blockquotes only — `remarkCallouts` rewrites alert blockquotes (`> [!NOTE]` etc.)
  // to `hName: "div"` before this runs, so callouts are handled by the `div` renderer below.
  blockquote: ({ children }) => (
    <blockquote className="my-5 border-l-4 border-signal-600/40 bg-paper-100 py-2 pl-4 text-ink-700 italic dark:border-signal-500/40 dark:bg-ink-800/60 dark:text-paper-200/90">
      {children}
    </blockquote>
  ),
  div: ({ children, ...rest }) => {
    const calloutType = (rest as { "data-callout"?: string })["data-callout"];
    if (isCalloutKey(calloutType)) {
      const { icon: Icon, label, classes } = CALLOUT_META[calloutType];
      return (
        <div className={cn("my-5 flex gap-3 rounded-xl border px-4 py-3.5", classes)} role="note" aria-label={label}>
          <Icon className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
          <div className="min-w-0 text-sm leading-6 [&>p]:my-0 [&>p:first-child]:mt-0 [&>p:last-child]:mb-0">
            <p className="mb-1 font-sans text-sm font-semibold">{label}</p>
            {children}
          </div>
        </div>
      );
    }
    return <div>{children}</div>;
  },
  pre: CodeBlock,
  code: ({ className, children }) => {
    if (className?.includes("language-")) {
      return <code className={className}>{children}</code>;
    }
    return (
      <code className="rounded-md bg-paper-200/70 px-1.5 py-0.5 font-mono text-[0.85em] text-ink-800 dark:bg-ink-800 dark:text-paper-100">
        {children}
      </code>
    );
  },
  table: ({ children }) => (
    <div className="my-5 overflow-x-auto rounded-lg border border-paper-200 dark:border-ink-800">
      <table className="w-full border-collapse text-sm">{children}</table>
    </div>
  ),
  thead: ({ children }) => <thead className="bg-paper-100 dark:bg-ink-800/80">{children}</thead>,
  tbody: ({ children }) => <tbody className="divide-y divide-paper-200 dark:divide-ink-800">{children}</tbody>,
  tr: ({ children }) => <tr>{children}</tr>,
  th: ({ children, style }) => (
    <th style={style} className="px-4 py-2.5 text-left font-sans text-xs font-semibold tracking-wide text-ink-700 uppercase dark:text-paper-200">
      {children}
    </th>
  ),
  td: ({ children, style }) => (
    <td style={style} className="px-4 py-2.5 align-top text-ink-700 dark:text-paper-200/90">
      {children}
    </td>
  ),
  img: ({ src, alt, title }) => (
    <figure className="my-6">
      <img src={src} alt={alt ?? ""} loading="lazy" className="w-full rounded-xl border border-paper-200 dark:border-ink-800" />
      {title && <figcaption className="mt-2 text-center text-sm text-ink-600 dark:text-paper-300/70">{title}</figcaption>}
    </figure>
  ),
};

interface MarkdownRendererProps {
  content: string;
}

/**
 * Renders sanitized Markdown for arbitrary, potentially untrusted documents.
 * `rehype-raw` is intentionally NOT used: react-markdown escapes raw HTML by
 * default, which prevents script/style injection from an uploaded file. If a
 * future requirement needs raw HTML passthrough, pair `rehype-raw` with
 * `rehype-sanitize` — never enable one without the other.
 */
export function MarkdownRenderer({ content }: MarkdownRendererProps): ReactNode {
  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm, remarkCallouts]}
      rehypePlugins={[rehypeSlug, rehypeHighlight]}
      components={components}
    >
      {content}
    </ReactMarkdown>
  );
}
