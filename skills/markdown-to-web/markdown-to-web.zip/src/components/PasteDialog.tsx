import { useEffect, useRef, useState } from "react";

interface PasteDialogProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (markdown: string) => void;
}

export function PasteDialog({ open, onClose, onSubmit }: PasteDialogProps) {
  const [value, setValue] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (open) {
      setValue("");
      textareaRef.current?.focus();
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/50 px-4 backdrop-blur-sm" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Paste Markdown"
        onClick={(event) => event.stopPropagation()}
        className="flex w-full max-w-2xl flex-col overflow-hidden rounded-xl border border-paper-200 bg-paper-0 shadow-xl dark:border-ink-700 dark:bg-ink-900"
      >
        <div className="border-b border-paper-200 px-5 py-3.5 dark:border-ink-800">
          <h2 className="font-display text-lg font-semibold text-ink-900 dark:text-paper-100">Paste Markdown</h2>
          <p className="mt-0.5 text-sm text-ink-600 dark:text-paper-300/70">
            Frontmatter, headings, and everything else render exactly as it would from a file.
          </p>
        </div>
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(event) => setValue(event.target.value)}
          placeholder={"---\ntitle: My Document\n---\n\n# Hello world"}
          className="h-64 w-full resize-none bg-transparent px-5 py-4 font-mono text-sm text-ink-900 outline-none placeholder:text-ink-400 dark:text-paper-100"
          aria-label="Markdown source"
        />
        <div className="flex justify-end gap-2 border-t border-paper-200 px-5 py-3.5 dark:border-ink-800">
          <button
            type="button"
            onClick={onClose}
            className="rounded-md px-3 py-1.5 text-sm font-medium text-ink-600 hover:bg-paper-100 dark:text-paper-300 dark:hover:bg-ink-800"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={!value.trim()}
            onClick={() => {
              onSubmit(value);
              onClose();
            }}
            className="rounded-md bg-signal-600 px-3 py-1.5 text-sm font-medium text-white transition hover:bg-signal-700 disabled:cursor-not-allowed disabled:opacity-40"
          >
            Render document
          </button>
        </div>
      </div>
    </div>
  );
}
