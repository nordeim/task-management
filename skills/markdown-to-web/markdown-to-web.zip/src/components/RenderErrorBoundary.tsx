import { Component, type ReactNode } from "react";

interface Props {
  children: ReactNode;
  /** Remounts the boundary's children when this key changes, so switching documents clears a prior error. */
  resetKey: string;
}

interface State {
  error: Error | null;
}

/**
 * Class component is a deliberate exception to the functional-components
 * convention: React only supports error boundaries via
 * `componentDidCatch`/`getDerivedStateFromError`, with no hook equivalent.
 * Without this, a malformed document that trips an edge case in a remark/
 * rehype plugin would blank the entire page instead of failing gracefully.
 */
export class RenderErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidUpdate(prevProps: Props) {
    if (prevProps.resetKey !== this.props.resetKey && this.state.error) {
      this.setState({ error: null });
    }
  }

  render() {
    if (this.state.error) {
      return (
        <div role="alert" className="rounded-xl border border-caution/30 bg-caution/[0.06] px-5 py-4 text-caution">
          <p className="font-semibold">This document couldn't be rendered.</p>
          <p className="mt-1 text-sm opacity-90">
            {this.state.error.message || "An unexpected error occurred while parsing the Markdown."} Try a different
            file, or check it for unusual formatting.
          </p>
        </div>
      );
    }
    return this.props.children;
  }
}
