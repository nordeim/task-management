import { Search, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { searchSections, type SearchSection } from "@/lib/search";
import { cn } from "@/utils/cn";

interface SearchDialogProps {
  sections: SearchSection[];
  open: boolean;
  onClose: () => void;
  onNavigate: (id: string) => void;
}

/**
 * Command-palette style in-document search. Matches against rendered text
 * (headings + body excerpts), not raw Markdown syntax, so queries like
 * "signature" find prose even when it's wrapped in `**bold**` or a link.
 */
export function SearchDialog({ sections, open, onClose, onNavigate }: SearchDialogProps) {
  const [query, setQuery] = useState("");
  const [highlightIndex, setHighlightIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const previouslyFocused = useRef<HTMLElement | null>(null);

  const results = useMemo(() => searchSections(sections, query).slice(0, 20), [sections, query]);

  useEffect(() => {
    if (!open) return;
    previouslyFocused.current = document.activeElement as HTMLElement | null;
    inputRef.current?.focus();
    return () => previouslyFocused.current?.focus();
  }, [open]);

  useEffect(() => {
    setHighlightIndex(0);
  }, [query]);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        onClose();
      } else if (event.key === "ArrowDown") {
        event.preventDefault();
        setHighlightIndex((prev) => Math.min(prev + 1, results.length - 1));
      } else if (event.key === "ArrowUp") {
        event.preventDefault();
        setHighlightIndex((prev) => Math.max(prev - 1, 0));
      } else if (event.key === "Enter" && results[highlightIndex]) {
        onNavigate(results[highlightIndex].id);
        onClose();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open, results, highlightIndex, onNavigate, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-ink-950/50 px-4 pt-24 backdrop-blur-sm" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Search document"
        onClick={(event) => event.stopPropagation()}
        className="w-full max-w-lg overflow-hidden rounded-xl border border-paper-200 bg-paper-0 shadow-xl dark:border-ink-700 dark:bg-ink-900"
      >
        <div className="flex items-center gap-3 border-b border-paper-200 px-4 py-3 dark:border-ink-800">
          <Search className="h-4 w-4 shrink-0 text-ink-400" aria-hidden />
          <input
            ref={inputRef}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            type="text"
            placeholder="Search this document…"
            className="w-full bg-transparent text-sm text-ink-900 outline-none placeholder:text-ink-400 dark:text-paper-100"
            aria-label="Search this document"
          />
          <button
            type="button"
            onClick={onClose}
            aria-label="Close search"
            className="rounded-md p-1 text-ink-400 hover:bg-paper-100 hover:text-ink-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-signal-500 dark:hover:bg-ink-800"
          >
            <X className="h-4 w-4" aria-hidden />
          </button>
        </div>

        <ul className="max-h-80 overflow-y-auto py-2" role="listbox" aria-label="Search results">
          {query.trim() === "" && (
            <li className="px-4 py-6 text-center text-sm text-ink-400">Type to search headings and body text.</li>
          )}
          {query.trim() !== "" && results.length === 0 && (
            <li className="px-4 py-6 text-center text-sm text-ink-400">No matches for "{query}".</li>
          )}
          {results.map((result, index) => (
            <li key={result.id} role="option" aria-selected={index === highlightIndex}>
              <button
                type="button"
                onClick={() => {
                  onNavigate(result.id);
                  onClose();
                }}
                onMouseEnter={() => setHighlightIndex(index)}
                className={cn(
                  "block w-full px-4 py-2.5 text-left transition",
                  index === highlightIndex ? "bg-signal-600/10 dark:bg-signal-500/15" : "hover:bg-paper-100 dark:hover:bg-ink-800",
                )}
              >
                <p className="truncate text-sm font-medium text-ink-900 dark:text-paper-100">{result.heading}</p>
                {result.excerpt && (
                  <p className="mt-0.5 line-clamp-1 text-xs text-ink-600 dark:text-paper-300/70">{result.excerpt}</p>
                )}
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
