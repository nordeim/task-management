import { AlertCircle, X } from "lucide-react";
import { useCallback, useMemo, useRef, useState, type ChangeEvent, type DragEvent } from "react";
import { DocumentInfo } from "@/components/DocumentInfo";
import { Header } from "@/components/Header";
import { MarkdownRenderer } from "@/components/MarkdownRenderer";
import { MobileDrawer } from "@/components/MobileDrawer";
import { PasteDialog } from "@/components/PasteDialog";
import { RenderErrorBoundary } from "@/components/RenderErrorBoundary";
import { SearchDialog } from "@/components/SearchDialog";
import { TableOfContents } from "@/components/TableOfContents";
import { DEFAULT_SAMPLE_ID, SAMPLE_DOCUMENTS } from "@/data/samples";
import { useActiveHeading } from "@/hooks/useActiveHeading";
import { useTheme } from "@/hooks/useTheme";
import { parseDocument } from "@/lib/document";
import { FileValidationError, readMarkdownFile } from "@/lib/loadFile";
import { buildSearchIndex } from "@/lib/search";
import { buildToc, flattenToc } from "@/lib/toc";

type SourceKind = "sample" | "file" | "pasted";

const defaultSample = SAMPLE_DOCUMENTS.find((sample) => sample.id === DEFAULT_SAMPLE_ID) ?? SAMPLE_DOCUMENTS[0];

function scrollToHeading(id: string) {
  const target = document.getElementById(id);
  if (!target) return;
  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  window.history.pushState(null, "", `#${id}`);
  target.scrollIntoView({ behavior: prefersReducedMotion ? "auto" : "smooth", block: "start" });
}

export default function App() {
  const [rawInput, setRawInput] = useState(defaultSample.raw);
  const [sourceKind, setSourceKind] = useState<SourceKind>("sample");
  const [activeSampleId, setActiveSampleId] = useState<string | null>(defaultSample.id);
  const [sourceLabel, setSourceLabel] = useState(defaultSample.label);
  const [error, setError] = useState<string | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [pasteOpen, setPasteOpen] = useState(false);
  const [isDraggingFile, setIsDraggingFile] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const dragCounter = useRef(0);
  const theme = useTheme();

  const parseResult = useMemo(() => {
    try {
      return { ok: true as const, doc: parseDocument(rawInput) };
    } catch (parseError) {
      return {
        ok: false as const,
        message: parseError instanceof Error ? parseError.message : "This document couldn't be parsed.",
      };
    }
  }, [rawInput]);

  const content = parseResult.ok ? parseResult.doc.content : "";
  const toc = useMemo(() => buildToc(content), [content]);
  const searchIndex = useMemo(() => buildSearchIndex(content), [content]);
  const flatIds = useMemo(() => flattenToc(toc).map((item) => item.id), [toc]);
  const activeId = useActiveHeading(flatIds);

  const documentTitle = (parseResult.ok && parseResult.doc.meta.title) || sourceLabel;

  const loadSample = useCallback((id: string) => {
    const sample = SAMPLE_DOCUMENTS.find((doc) => doc.id === id);
    if (!sample) return;
    setRawInput(sample.raw);
    setSourceKind("sample");
    setActiveSampleId(sample.id);
    setSourceLabel(sample.label);
    setError(null);
  }, []);

  const loadFile = useCallback(async (file: File) => {
    try {
      const text = await readMarkdownFile(file);
      setRawInput(text);
      setSourceKind("file");
      setActiveSampleId(null);
      setSourceLabel(file.name);
      setError(null);
    } catch (fileError) {
      setError(fileError instanceof FileValidationError ? fileError.message : "Couldn't read that file.");
    }
  }, []);

  const handleFileChosen = useCallback(
    (event: ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      event.target.value = "";
      if (file) void loadFile(file);
    },
    [loadFile],
  );

  const handlePasteSubmit = useCallback((markdown: string) => {
    setRawInput(markdown);
    setSourceKind("pasted");
    setActiveSampleId(null);
    setSourceLabel("Pasted document");
    setError(null);
  }, []);

  const handleDrop = useCallback(
    (event: DragEvent<HTMLDivElement>) => {
      event.preventDefault();
      dragCounter.current = 0;
      setIsDraggingFile(false);
      const file = event.dataTransfer.files?.[0];
      if (file) void loadFile(file);
    },
    [loadFile],
  );

  const handleDragEnter = useCallback((event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    if (event.dataTransfer.types.includes("Files")) {
      dragCounter.current += 1;
      setIsDraggingFile(true);
    }
  }, []);

  const handleDragLeave = useCallback((event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    dragCounter.current = Math.max(0, dragCounter.current - 1);
    if (dragCounter.current === 0) setIsDraggingFile(false);
  }, []);

  const navigateToId = useCallback((id: string) => {
    scrollToHeading(id);
  }, []);

  void sourceKind;

  return (
    <div
      className="min-h-screen bg-paper-50 text-ink-900 dark:bg-ink-950 dark:text-paper-100"
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={(event) => event.preventDefault()}
      onDrop={handleDrop}
    >
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:rounded-md focus:bg-signal-600 focus:px-4 focus:py-2 focus:text-sm focus:font-medium focus:text-white"
      >
        Skip to document content
      </a>

      <Header
        documentTitle={documentTitle}
        samples={SAMPLE_DOCUMENTS}
        activeSampleId={activeSampleId}
        onSelectSample={loadSample}
        fileInputRef={fileInputRef}
        onFileChosen={handleFileChosen}
        onOpenPaste={() => setPasteOpen(true)}
        onOpenSearch={() => setSearchOpen(true)}
        onToggleDrawer={() => setDrawerOpen(true)}
        themePreference={theme.preference}
        onCycleTheme={theme.cycle}
      />

      {error && (
        <div className="mx-auto flex max-w-6xl items-start gap-3 px-4 pt-4 sm:px-6">
          <div className="flex w-full items-start gap-2.5 rounded-lg border border-caution/30 bg-caution/[0.06] px-4 py-3 text-sm text-caution">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
            <p className="flex-1">{error}</p>
            <button type="button" onClick={() => setError(null)} aria-label="Dismiss error" className="shrink-0 opacity-70 hover:opacity-100">
              <X className="h-4 w-4" aria-hidden />
            </button>
          </div>
        </div>
      )}

      <div className="mx-auto flex max-w-6xl gap-10 px-4 py-8 sm:px-6 lg:py-12">
        <aside className="hidden w-64 shrink-0 lg:block">
          <div className="sticky top-20 max-h-[calc(100vh-6rem)] overflow-y-auto pb-8">
            <p className="mb-3 px-1 font-mono text-xs font-semibold tracking-widest text-ink-500 uppercase dark:text-paper-300/60">
              On this page
            </p>
            <TableOfContents items={toc} activeId={activeId} />
          </div>
        </aside>

        <main id="main-content" className="min-w-0 flex-1">
          {isDraggingFile && (
            <div className="mb-4 rounded-xl border-2 border-dashed border-signal-600 bg-signal-600/5 px-4 py-6 text-center text-sm font-medium text-signal-700 dark:text-signal-400">
              Drop your Markdown file to load it
            </div>
          )}

          {parseResult.ok ? (
            <>
              <DocumentInfo
                meta={parseResult.doc.meta}
                wordCount={parseResult.doc.wordCount}
                readingTimeMinutes={parseResult.doc.readingTimeMinutes}
              />
              <RenderErrorBoundary resetKey={rawInput}>
                <article className="max-w-none">
                  <MarkdownRenderer content={parseResult.doc.content} />
                </article>
              </RenderErrorBoundary>
            </>
          ) : (
            <div role="alert" className="rounded-xl border border-caution/30 bg-caution/[0.06] px-5 py-4 text-caution">
              <p className="font-semibold">This document couldn't be loaded.</p>
              <p className="mt-1 text-sm opacity-90">{parseResult.message}</p>
            </div>
          )}
        </main>
      </div>

      <MobileDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)} title="On this page">
        <TableOfContents items={toc} activeId={activeId} onNavigate={() => setDrawerOpen(false)} />
      </MobileDrawer>

      <SearchDialog
        sections={searchIndex}
        open={searchOpen}
        onClose={() => setSearchOpen(false)}
        onNavigate={navigateToId}
      />

      <PasteDialog open={pasteOpen} onClose={() => setPasteOpen(false)} onSubmit={handlePasteSubmit} />
    </div>
  );
}
