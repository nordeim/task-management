---
title: Markdown Reader — Feature Tour
description: A guided tour of every rendering feature this reader supports, written as a real document instead of a spec sheet.
author: Documentation Team
date: 2026-01-14
tags: [guide, reference, markdown]
---

# Markdown Reader — Feature Tour

This document is both a demo and a reference. Everything below is rendered by
the same pipeline that would render your own `README.md`, a design spec, or an
internal runbook — drop any Markdown file in and it looks like this.

## Text formatting

You can mix **bold**, *italic*, ***bold italic***, ~~strikethrough~~, and
`inline code` freely inside a sentence, along with [links to external
sites](https://developer.mozilla.org/en-US/docs/Web/Markdown) and footnotes
for asides that shouldn't interrupt the sentence flow.[^1]

[^1]: Footnotes render at the bottom of the document and jump back and forth via anchor links.

## Callouts

Callouts use the same syntax GitHub supports, so documents copy over without edits.

> [!NOTE]
> Callouts are just blockquotes with a `[!TYPE]` marker on the first line. Five types are supported: note, tip, important, warning, and caution.

> [!TIP]
> Use callouts sparingly — three or four per document keeps them meaningful instead of decorative noise.

> [!IMPORTANT]
> Uploaded documents are rendered as **text only**. Raw HTML embedded in Markdown is never executed, which keeps arbitrary or untrusted files safe to open.

> [!WARNING]
> Very large documents (over 5 MB) are rejected before parsing to keep the reader responsive.

> [!CAUTION]
> This reader does not fetch or execute remote scripts referenced in a document — only images and standard Markdown constructs are rendered.

## Code blocks

Fenced code blocks get a language label, syntax highlighting, and a copy button.

```typescript
interface ReadingStats {
  wordCount: number;
  readingTimeMinutes: number;
}

function estimateReadingTime(words: number, wpm = 200): number {
  return Math.max(1, Math.round(words / wpm));
}
```

```bash
# Renders shell scripts with the same styling
npm install
npm run build
```

## Tables

GitHub-flavored tables render with sticky headers and horizontal scrolling on narrow screens.

| Feature | Supported | Notes |
| --- | :---: | --- |
| Tables | ✅ | via `remark-gfm` |
| Task lists | ✅ | see below |
| Footnotes | ✅ | see above |
| Strikethrough | ✅ | `~~text~~` |
| Raw HTML | ❌ (by design) | prevents script injection from untrusted files |

## Task lists

- [x] Parse frontmatter metadata
- [x] Build a nested table of contents
- [x] Add syntax-highlighted code blocks
- [ ] Add full-text search across every open document

## Images

Images scale to the content width and any `title` attribute becomes a caption.

![Two colleagues reviewing a plan on a whiteboard](https://images.pexels.com/photos/7495607/pexels-photo-7495607.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200 "Documentation works best when it's written the way teams actually plan.")

## Nested headings

### This is an H3

Headings down to H4 appear in the table of contents, nested under their parent section.

#### This is an H4

The deepest level the outline tracks — anything past H4 still renders, just without a TOC entry, to keep the sidebar scannable on long documents.

## Wrapping up

Load your own file with **Open file** in the header, or paste Markdown directly — the outline, search index, and reading time all recompute automatically.
