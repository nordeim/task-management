---
title: Webhooks API Reference
description: Endpoints, payload shapes, and retry behavior for outbound webhooks.
author: API Platform
date: 2026-02-20
tags: [api, reference, webhooks]
---

# Webhooks API Reference

Outbound webhooks notify your service when events happen on an account —
subscriptions, payments, and shipment updates. This reference covers
registration, payload shape, signature verification, and retries.

## Registering an endpoint

```bash
curl -X POST https://api.example.com/v1/webhooks \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://your-app.example.com/hooks/inbound",
    "events": ["order.created", "order.shipped"]
  }'
```

> [!WARNING]
> Endpoint URLs must use HTTPS. HTTP endpoints are rejected at registration time and cannot be enabled later without re-registering.

## Event payload

Every event is delivered as a signed JSON POST body:

```json
{
  "id": "evt_1a2b3c",
  "type": "order.shipped",
  "created": "2026-02-20T18:04:11Z",
  "data": {
    "order_id": "ord_9f8e7d",
    "tracking_number": "1Z999AA10123456784"
  }
}
```

| Field | Type | Description |
| --- | --- | --- |
| `id` | string | Unique event identifier, stable across retries |
| `type` | string | Dot-separated event name, e.g. `order.shipped` |
| `created` | string | ISO-8601 timestamp of when the event occurred |
| `data` | object | Event-specific payload — schema varies by `type` |

## Verifying signatures

Every request includes an `X-Signature` header: an HMAC-SHA256 digest of the
raw request body, keyed with your endpoint's signing secret.

```typescript
import { createHmac, timingSafeEqual } from "node:crypto";

function isValidSignature(rawBody: string, signature: string, secret: string): boolean {
  const expected = createHmac("sha256", secret).update(rawBody).digest("hex");
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(signature, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}
```

> [!CAUTION]
> Always compare signatures with a constant-time function. A naive `===` string comparison leaks timing information an attacker can use to forge signatures byte by byte.

## Retries

Failed deliveries (non-2xx response, or no response within 10 seconds) are
retried with exponential backoff:

- [x] Attempt 1 — immediately
- [x] Attempt 2 — after 1 minute
- [x] Attempt 3 — after 10 minutes
- [x] Attempt 4 — after 1 hour
- [ ] Attempt 5 — after 6 hours, then the endpoint is marked unhealthy

> [!IMPORTANT]
> An endpoint marked unhealthy stops receiving new events until you send a test event from the dashboard to re-enable it. Queued events during the unhealthy window are **not** replayed automatically — request a replay via `POST /v1/webhooks/{id}/replay` if needed.

## Event types

| Event | Fires when |
| --- | --- |
| `order.created` | A new order is placed |
| `order.shipped` | A shipment is dispatched, includes tracking data |
| `order.cancelled` | An order is cancelled before shipment |
| `payment.failed` | A payment attempt is declined |

## Testing locally

Use the CLI to forward events to `localhost` during development:

```bash
webhook-cli listen --forward-to localhost:3000/hooks/inbound
```

This opens a tunnel and replays real event payloads against your local
server, signed with a throwaway secret printed to the terminal.
