---
title: Engineering Onboarding Handbook
description: What to do in your first two weeks on the platform team.
author: Platform Team
date: 2025-11-03
tags: [onboarding, engineering, handbook]
---

# Engineering Onboarding Handbook

Welcome to the platform team. This handbook covers your first two weeks:
accounts, local setup, how we ship code, and who to ask when you're stuck.

## Week one

### Day one: accounts and access

- [x] Laptop provisioned and encrypted
- [x] Git host, issue tracker, and chat accounts created
- [ ] VPN and production read-access requested (approved by your manager)
- [ ] Added to the on-call rotation calendar (view-only until week four)

> [!NOTE]
> Access requests route through the identity team and can take up to one business day. File yours before end of day one.

### Local environment

Clone the monorepo and bootstrap dependencies:

```bash
git clone git@example.com:platform/monorepo.git
cd monorepo
./scripts/bootstrap.sh
```

The bootstrap script installs language toolchains pinned per-project, so avoid
installing Node, Go, or Python globally with a different version manager —
version drift here is the most common "works on my machine" bug new hires hit.

### How we ship code

1. Branch from `main`, one logical change per branch.
2. Open a pull request; CI runs lint, type-check, and tests automatically.
3. A teammate reviews within one business day for most changes.
4. Merges to `main` deploy to staging automatically; production deploys are manual and gated by a release owner.

> [!TIP]
> Small, frequent pull requests get reviewed faster than large ones. If a change grows past ~400 lines, consider splitting it.

## Week two

### Shadow an on-call shift

You'll shadow (not carry) the pager for one shift. The goal is to see how
incidents are triaged, not to resolve them solo.

| Severity | Response target | Who's paged |
| --- | --- | --- |
| SEV-1 | 5 minutes | Primary + secondary on-call |
| SEV-2 | 30 minutes | Primary on-call |
| SEV-3 | Next business day | Assigned via ticket |

> [!IMPORTANT]
> If you're ever unsure whether something is a SEV-1, treat it as one. Paging unnecessarily is a five-minute inconvenience; missing a real outage is not.

### Ship your first change

Most new hires ship a small, real fix by the end of week two — a flaky test,
a documentation gap, or a small paper-cut bug. Your onboarding buddy will help
you pick one.

## Who to ask

- **Local environment issues** — `#platform-eng` channel
- **Access and accounts** — identity team, `#it-access`
- **"Is this a SEV-1?"** — page on-call; asking is always the right call

## Glossary

| Term | Meaning |
| --- | --- |
| **Monorepo** | A single repository containing every service, rather than one repository per service. |
| **SEV** | Severity level assigned to an incident, from SEV-1 (critical) to SEV-3 (minor). |
